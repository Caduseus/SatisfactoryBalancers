Extract files to %localappdata%\FactoryGame\Saved\SaveGames\blueprints

You need to have Blueprint tech researched to use these blueprints.

Tier 1-4 belt blueprints for 3x3, 6x6 and 9x9 balancers are coming in a later version.